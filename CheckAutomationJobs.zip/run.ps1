param($Timer)

$resourceGroup = "GPS_PBI_CONTROLADORIA"
$automationAccount = "autocontroladoria"

try {
    Write-Output "🔍 Verificando jobs da conta de automação..."

    $jobs = Get-AzAutomationJob -ResourceGroupName $resourceGroup -AutomationAccountName $automationAccount -ErrorAction Stop

    $recent = $jobs | Where-Object {
        $_.Status -eq "Failed" -and $_.CreationTime -gt (Get-Date).AddMinutes(-15)
    }

    if ($recent.Count -gt 0) {
        Write-Output "‼️ Falhas recentes encontradas: $($recent.Count)"
        foreach ($job in $recent) {
            Write-Output "❌ Runbook: $($job.RunbookName) | Job ID: $($job.JobId) | Criado: $($job.CreationTime)"
        }
    } else {
        Write-Output "✅ Nenhuma falha nas últimas execuções."
    }
} catch {
    Write-Error "❌ Erro ao consultar jobs: $($_.Exception.Message)"
}